import { SignupForm } from "@/components/auth/signup-form"
import { AuthLayout } from "@/components/auth/auth-layout"

export default function SignupPage() {
  return (
    <AuthLayout
      title="Start your journey"
      subtitle="Create an account to begin tracking your nutrition"
    >
      <SignupForm />
    </AuthLayout>
  )
}
