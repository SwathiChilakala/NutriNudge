"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Droplets, Plus, Minus, Bell, Target, TrendingUp } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

const weeklyData = [
  { day: "Mon", glasses: 7 },
  { day: "Tue", glasses: 8 },
  { day: "Wed", glasses: 6 },
  { day: "Thu", glasses: 8 },
  { day: "Fri", glasses: 5 },
  { day: "Sat", glasses: 7 },
  { day: "Sun", glasses: 5 },
]

const waterLog = [
  { time: "08:00 AM", amount: 1 },
  { time: "10:30 AM", amount: 1 },
  { time: "12:00 PM", amount: 2 },
  { time: "03:00 PM", amount: 1 },
]

export default function HydrationPage() {
  const [currentGlasses, setCurrentGlasses] = useState(5)
  const [dailyGoal, setDailyGoal] = useState(8)
  const percentage = Math.min((currentGlasses / dailyGoal) * 100, 100)

  const addGlass = () => {
    setCurrentGlasses(prev => Math.min(prev + 1, 20))
  }

  const removeGlass = () => {
    setCurrentGlasses(prev => Math.max(prev - 1, 0))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Hydration Tracker</h1>
        <p className="text-muted-foreground mt-1">Stay on top of your daily water intake</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Tracker */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-8">
                {/* Water visualization */}
                <div className="relative w-48 h-48">
                  <svg className="w-48 h-48 -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="oklch(0.88 0.05 145)"
                      strokeWidth="10"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="oklch(0.65 0.12 160)"
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray={`${percentage * 2.83} 283`}
                      className="transition-all duration-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Droplets className="w-8 h-8 text-chart-3 mb-1" />
                    <span className="text-4xl font-bold text-foreground">{currentGlasses}</span>
                    <span className="text-sm text-muted-foreground">of {dailyGoal} glasses</span>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex-1 space-y-6">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Quick Add</p>
                    <div className="flex items-center gap-4">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={removeGlass}
                        className="h-12 w-12 rounded-full border-border text-foreground"
                      >
                        <Minus className="w-5 h-5" />
                      </Button>
                      <div className="flex gap-2">
                        {[1, 2, 3].map((num) => (
                          <Button
                            key={num}
                            variant="outline"
                            onClick={() => setCurrentGlasses(prev => Math.min(prev + num, 20))}
                            className="h-12 px-6 border-border text-foreground hover:bg-chart-3/10 hover:border-chart-3/50"
                          >
                            +{num}
                          </Button>
                        ))}
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={addGlass}
                        className="h-12 w-12 rounded-full border-border text-foreground"
                      >
                        <Plus className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Progress</p>
                    <div className="h-4 bg-accent rounded-full overflow-hidden">
                      <div
                        className="h-full bg-chart-3 rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {percentage >= 100 
                        ? "Goal reached! Great job staying hydrated!"
                        : `${dailyGoal - currentGlasses} more glasses to reach your goal`
                      }
                    </p>
                  </div>

                  <Button className="bg-chart-3 text-primary-foreground hover:bg-chart-3/90">
                    <Plus className="w-4 h-4 mr-2" />
                    Log 1 Glass (250ml)
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Weekly Chart */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">Weekly Hydration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.04 145)" />
                    <XAxis
                      dataKey="day"
                      tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                      axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                      axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.99 0.01 145)",
                        border: "1px solid oklch(0.88 0.04 145)",
                        borderRadius: "12px",
                        color: "oklch(0.2 0.04 145)",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="glasses"
                      stroke="oklch(0.65 0.12 160)"
                      strokeWidth={3}
                      dot={{ fill: "oklch(0.65 0.12 160)", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Stats */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                    <Target className="w-5 h-5 text-chart-3" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Daily Goal</p>
                    <p className="font-semibold text-foreground">{dailyGoal} glasses</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Weekly Avg</p>
                    <p className="font-semibold text-foreground">6.6 glasses</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-chart-4/10 flex items-center justify-center">
                    <Droplets className="w-5 h-5 text-chart-4" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Goals Met</p>
                    <p className="font-semibold text-foreground">5/7 days</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Reminders */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                <Bell className="w-5 h-5 text-primary" />
                Reminders
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">Get reminded to drink water</p>
              <div className="space-y-2">
                {["Every 2 hours", "Every 3 hours", "Custom"].map((option, index) => (
                  <Button
                    key={option}
                    variant={index === 0 ? "default" : "outline"}
                    className={`w-full justify-start ${index === 0 ? 'bg-primary text-primary-foreground' : 'border-border text-foreground'}`}
                  >
                    {option}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Today's Log */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">Today&apos;s Log</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {waterLog.map((entry, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent/30">
                    <span className="text-sm text-muted-foreground">{entry.time}</span>
                    <span className="text-sm font-medium text-foreground">{entry.amount} glass{entry.amount > 1 ? 'es' : ''}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
