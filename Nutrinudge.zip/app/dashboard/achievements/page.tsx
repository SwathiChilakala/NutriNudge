"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, Flame, Star, Target, Droplets, Apple, Award, Lock, TrendingUp, Zap, Crown, Medal, Gift } from "lucide-react"

const streakData = {
  current: 12,
  best: 21,
  thisWeek: 7,
  thisMonth: 26
}

const badges = [
  { id: 1, name: "First Steps", description: "Log your first meal", icon: Star, earned: true, date: "Jan 15, 2026", color: "bg-chart-4" },
  { id: 2, name: "Hydration Hero", description: "Drink 8 glasses for 7 days straight", icon: Droplets, earned: true, date: "Jan 22, 2026", color: "bg-chart-3" },
  { id: 3, name: "Consistency King", description: "Log meals for 14 days in a row", icon: Crown, earned: true, date: "Feb 1, 2026", color: "bg-primary" },
  { id: 4, name: "Early Bird", description: "Eat breakfast before 9am for a week", icon: Zap, earned: true, date: "Feb 10, 2026", color: "bg-chart-1" },
  { id: 5, name: "Veggie Lover", description: "Eat 5 servings of vegetables daily for a week", icon: Apple, earned: true, date: "Feb 15, 2026", color: "bg-primary" },
  { id: 6, name: "Perfect Week", description: "Hit all daily goals for 7 days", icon: Medal, earned: false, progress: 5, total: 7, color: "bg-chart-2" },
  { id: 7, name: "Marathon Month", description: "Log meals every day for 30 days", icon: Trophy, earned: false, progress: 26, total: 30, color: "bg-chart-4" },
  { id: 8, name: "Discipline Master", description: "Reach a discipline score of 90+", icon: Target, earned: false, progress: 82, total: 90, color: "bg-primary" },
  { id: 9, name: "Century Club", description: "Log 100 healthy meals", icon: Award, earned: false, progress: 78, total: 100, color: "bg-chart-1" },
  { id: 10, name: "Hydration Legend", description: "Hit water goal for 30 days", icon: Droplets, earned: false, progress: 18, total: 30, color: "bg-chart-3" },
]

const rewards = [
  { name: "Custom Themes", points: 500, unlocked: true },
  { name: "Premium Recipes", points: 1000, unlocked: true },
  { name: "AI Coach", points: 2000, unlocked: false },
  { name: "Meal Planner", points: 3500, unlocked: false },
]

const leaderboard = [
  { rank: 1, name: "Emma S.", score: 2450, avatar: "ES" },
  { rank: 2, name: "Michael R.", score: 2380, avatar: "MR" },
  { rank: 3, name: "Sarah K.", score: 2290, avatar: "SK" },
  { rank: 4, name: "You", score: 2180, avatar: "JD", isUser: true },
  { rank: 5, name: "David L.", score: 2050, avatar: "DL" },
]

export default function AchievementsPage() {
  const totalPoints = 2180
  const earnedBadges = badges.filter(b => b.earned).length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Achievements</h1>
        <p className="text-muted-foreground mt-1">Track your progress and earn rewards for healthy habits</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-primary/10 border-primary/20">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
              <Flame className="w-6 h-6 text-primary" />
            </div>
            <p className="text-3xl font-bold text-foreground">{streakData.current}</p>
            <p className="text-sm text-muted-foreground">Day Streak</p>
          </CardContent>
        </Card>
        <Card className="bg-chart-4/10 border-chart-4/20">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-chart-4/20 flex items-center justify-center mx-auto mb-2">
              <Trophy className="w-6 h-6 text-chart-4" />
            </div>
            <p className="text-3xl font-bold text-foreground">{earnedBadges}</p>
            <p className="text-sm text-muted-foreground">Badges Earned</p>
          </CardContent>
        </Card>
        <Card className="bg-chart-3/10 border-chart-3/20">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-chart-3/20 flex items-center justify-center mx-auto mb-2">
              <Star className="w-6 h-6 text-chart-3" />
            </div>
            <p className="text-3xl font-bold text-foreground">{totalPoints}</p>
            <p className="text-sm text-muted-foreground">Total Points</p>
          </CardContent>
        </Card>
        <Card className="bg-chart-1/10 border-chart-1/20">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-chart-1/20 flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="w-6 h-6 text-chart-1" />
            </div>
            <p className="text-3xl font-bold text-foreground">{streakData.best}</p>
            <p className="text-sm text-muted-foreground">Best Streak</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Badges Section */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" />
                Badges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {badges.map((badge) => (
                  <div
                    key={badge.id}
                    className={`p-4 rounded-xl border transition-all ${
                      badge.earned 
                        ? 'bg-accent/30 border-border hover:border-primary/50' 
                        : 'bg-accent/10 border-border/50 opacity-70'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-12 h-12 rounded-xl ${badge.earned ? badge.color : 'bg-muted'} flex items-center justify-center shrink-0`}>
                        {badge.earned ? (
                          <badge.icon className="w-6 h-6 text-primary-foreground" />
                        ) : (
                          <Lock className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground">{badge.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{badge.description}</p>
                        {badge.earned ? (
                          <p className="text-xs text-primary mt-2">Earned on {badge.date}</p>
                        ) : (
                          <div className="mt-2">
                            <div className="h-1.5 bg-accent rounded-full overflow-hidden">
                              <div
                                className="h-full bg-primary rounded-full transition-all"
                                style={{ width: `${((badge.progress || 0) / (badge.total || 1)) * 100}%` }}
                              />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {badge.progress}/{badge.total}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Rewards Section */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                <Gift className="w-5 h-5 text-primary" />
                Rewards Shop
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {rewards.map((reward, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-xl border ${
                      reward.unlocked 
                        ? 'bg-primary/5 border-primary/20' 
                        : 'bg-accent/10 border-border'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-foreground">{reward.name}</p>
                        <p className="text-sm text-muted-foreground">{reward.points} points</p>
                      </div>
                      {reward.unlocked ? (
                        <Button size="sm" variant="outline" className="border-primary text-primary hover:bg-primary/10">
                          Use
                        </Button>
                      ) : (
                        <div className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-sm">
                          {reward.points - totalPoints} more
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Streak Card */}
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6 text-center">
              <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <Flame className="w-10 h-10 text-primary" />
              </div>
              <p className="text-5xl font-bold text-foreground mb-1">{streakData.current}</p>
              <p className="text-muted-foreground mb-4">Day Streak</p>
              <div className="flex justify-center gap-1 mb-4">
                {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                  <div
                    key={i}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                      i < streakData.thisWeek 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-accent text-muted-foreground'
                    }`}
                  >
                    {day}
                  </div>
                ))}
              </div>
              <p className="text-sm text-muted-foreground">
                {21 - streakData.current > 0 
                  ? `${21 - streakData.current} days until next milestone!`
                  : 'Milestone reached!'
                }
              </p>
            </CardContent>
          </Card>

          {/* Leaderboard */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                <Award className="w-5 h-5 text-chart-4" />
                Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {leaderboard.map((user) => (
                  <div
                    key={user.rank}
                    className={`flex items-center gap-3 p-2 rounded-lg ${
                      user.isUser ? 'bg-primary/10 border border-primary/20' : 'hover:bg-accent/30'
                    }`}
                  >
                    <span className={`w-6 text-sm font-bold ${
                      user.rank === 1 ? 'text-chart-4' : 
                      user.rank === 2 ? 'text-muted-foreground' : 
                      user.rank === 3 ? 'text-chart-1' : 'text-muted-foreground'
                    }`}>
                      #{user.rank}
                    </span>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      user.isUser ? 'bg-primary text-primary-foreground' : 'bg-accent'
                    }`}>
                      <span className="text-xs font-semibold">{user.avatar}</span>
                    </div>
                    <span className={`flex-1 text-sm ${user.isUser ? 'font-semibold text-foreground' : 'text-foreground'}`}>
                      {user.name}
                    </span>
                    <span className="text-sm font-medium text-muted-foreground">{user.score}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Daily Challenge */}
          <Card className="bg-chart-3/5 border-chart-3/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-chart-3/20 flex items-center justify-center">
                  <Target className="w-5 h-5 text-chart-3" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Daily Challenge</p>
                  <p className="text-xs text-muted-foreground">Log 5 healthy meals today</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-2 bg-accent rounded-full overflow-hidden">
                  <div className="h-full bg-chart-3 rounded-full w-3/5" />
                </div>
                <p className="text-xs text-muted-foreground">3/5 completed - 50 bonus points</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
