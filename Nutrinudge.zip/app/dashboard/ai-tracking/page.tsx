"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Camera, Upload, Sparkles, Check, Edit2, Loader2 } from "lucide-react"

interface DetectedFood {
  name: string
  calories: number
  protein: number
  carbs: number
  fat: number
  confidence: number
}

export default function AITrackingPage() {
  const [image, setImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [detectedFood, setDetectedFood] = useState<DetectedFood | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [editedFood, setEditedFood] = useState<DetectedFood | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
        analyzeImage()
      }
      reader.readAsDataURL(file)
    }
  }

  const analyzeImage = async () => {
    setIsAnalyzing(true)
    setDetectedFood(null)
    
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const mockDetectedFood: DetectedFood = {
      name: "Grilled Chicken Salad",
      calories: 420,
      protein: 35,
      carbs: 18,
      fat: 22,
      confidence: 94
    }
    
    setDetectedFood(mockDetectedFood)
    setEditedFood(mockDetectedFood)
    setIsAnalyzing(false)
  }

  const handleSave = () => {
    // Here you would save to your backend
    alert("Meal saved successfully!")
    setImage(null)
    setDetectedFood(null)
    setEditedFood(null)
    setIsEditing(false)
  }

  const handleReset = () => {
    setImage(null)
    setDetectedFood(null)
    setEditedFood(null)
    setIsEditing(false)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">AI Food Tracking</h1>
        <p className="text-muted-foreground mt-1">Take a photo of your meal for instant nutrition analysis</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upload Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" />
              Upload Food Image
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!image ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-border rounded-xl p-12 text-center cursor-pointer hover:border-primary/50 hover:bg-accent/30 transition-colors"
              >
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-primary" />
                </div>
                <p className="text-foreground font-medium mb-2">Click to upload an image</p>
                <p className="text-sm text-muted-foreground">or drag and drop</p>
                <p className="text-xs text-muted-foreground mt-2">PNG, JPG up to 10MB</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative rounded-xl overflow-hidden">
                  <img src={image} alt="Uploaded food" className="w-full h-64 object-cover" />
                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-foreground/50 flex items-center justify-center">
                      <div className="text-center">
                        <Loader2 className="w-8 h-8 text-primary-foreground animate-spin mx-auto mb-2" />
                        <p className="text-primary-foreground font-medium">Analyzing food...</p>
                      </div>
                    </div>
                  )}
                </div>
                <Button variant="outline" onClick={handleReset} className="w-full border-border text-foreground">
                  Upload Different Image
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              AI Analysis Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!detectedFood && !isAnalyzing && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-8 h-8 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground">Upload an image to see AI analysis</p>
              </div>
            )}

            {isAnalyzing && (
              <div className="text-center py-12">
                <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
                <p className="text-foreground font-medium">Our AI is analyzing your food...</p>
                <p className="text-sm text-muted-foreground mt-1">This usually takes a few seconds</p>
              </div>
            )}

            {detectedFood && editedFood && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-primary" />
                    <span className="text-sm text-muted-foreground">
                      {detectedFood.confidence}% confidence
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                    className="text-primary hover:bg-primary/10"
                  >
                    <Edit2 className="w-4 h-4 mr-1" />
                    {isEditing ? "Done Editing" : "Edit"}
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-foreground">Detected Food</Label>
                    {isEditing ? (
                      <Input
                        value={editedFood.name}
                        onChange={(e) => setEditedFood({...editedFood, name: e.target.value})}
                        className="bg-input border-border text-foreground"
                      />
                    ) : (
                      <p className="text-xl font-semibold text-foreground">{editedFood.name}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-primary/10 text-center">
                      <p className="text-2xl font-bold text-primary">{editedFood.calories}</p>
                      <p className="text-sm text-muted-foreground">Calories</p>
                      {isEditing && (
                        <Input
                          type="number"
                          value={editedFood.calories}
                          onChange={(e) => setEditedFood({...editedFood, calories: parseInt(e.target.value) || 0})}
                          className="mt-2 bg-input border-border text-foreground text-center"
                        />
                      )}
                    </div>
                    <div className="p-4 rounded-xl bg-chart-2/10 text-center">
                      <p className="text-2xl font-bold text-chart-2">{editedFood.protein}g</p>
                      <p className="text-sm text-muted-foreground">Protein</p>
                      {isEditing && (
                        <Input
                          type="number"
                          value={editedFood.protein}
                          onChange={(e) => setEditedFood({...editedFood, protein: parseInt(e.target.value) || 0})}
                          className="mt-2 bg-input border-border text-foreground text-center"
                        />
                      )}
                    </div>
                    <div className="p-4 rounded-xl bg-chart-3/10 text-center">
                      <p className="text-2xl font-bold text-chart-3">{editedFood.carbs}g</p>
                      <p className="text-sm text-muted-foreground">Carbs</p>
                      {isEditing && (
                        <Input
                          type="number"
                          value={editedFood.carbs}
                          onChange={(e) => setEditedFood({...editedFood, carbs: parseInt(e.target.value) || 0})}
                          className="mt-2 bg-input border-border text-foreground text-center"
                        />
                      )}
                    </div>
                    <div className="p-4 rounded-xl bg-chart-4/10 text-center">
                      <p className="text-2xl font-bold text-chart-4">{editedFood.fat}g</p>
                      <p className="text-sm text-muted-foreground">Fat</p>
                      {isEditing && (
                        <Input
                          type="number"
                          value={editedFood.fat}
                          onChange={(e) => setEditedFood({...editedFood, fat: parseInt(e.target.value) || 0})}
                          className="mt-2 bg-input border-border text-foreground text-center"
                        />
                      )}
                    </div>
                  </div>
                </div>

                <Button onClick={handleSave} className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                  <Check className="w-4 h-4 mr-2" />
                  Save to Food Log
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tips Section */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Tips for Better Results
          </h3>
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-semibold text-primary">1</span>
              </div>
              <p className="text-sm text-muted-foreground">Take photos in good lighting for more accurate analysis</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-semibold text-primary">2</span>
              </div>
              <p className="text-sm text-muted-foreground">Include the entire plate or dish in the frame</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-semibold text-primary">3</span>
              </div>
              <p className="text-sm text-muted-foreground">Review and edit detected values for accuracy</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
