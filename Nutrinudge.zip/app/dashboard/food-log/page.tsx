"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Clock, Trash2, Edit2 } from "lucide-react"

const mealTypes = ["Breakfast", "Lunch", "Dinner", "Snack"]

const recentFoods = [
  { name: "Oatmeal with Berries", calories: 320, protein: 12, carbs: 58, fat: 6 },
  { name: "Grilled Chicken Breast", calories: 165, protein: 31, carbs: 0, fat: 4 },
  { name: "Greek Yogurt", calories: 150, protein: 15, carbs: 10, fat: 5 },
  { name: "Banana", calories: 105, protein: 1, carbs: 27, fat: 0 },
  { name: "Salmon Fillet", calories: 280, protein: 35, carbs: 0, fat: 15 },
]

interface Meal {
  id: number
  name: string
  type: string
  calories: number
  protein: number
  carbs: number
  fat: number
  time: string
  portion: string
}

export default function FoodLogPage() {
  const [meals, setMeals] = useState<Meal[]>([
    { id: 1, name: "Oatmeal with Berries", type: "Breakfast", calories: 320, protein: 12, carbs: 58, fat: 6, time: "08:00", portion: "1 bowl" },
    { id: 2, name: "Grilled Chicken Salad", type: "Lunch", calories: 450, protein: 35, carbs: 20, fat: 15, time: "12:30", portion: "1 plate" },
  ])
  
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    type: "Breakfast",
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    time: "",
    portion: ""
  })
  const [searchQuery, setSearchQuery] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newMeal: Meal = {
      id: Date.now(),
      name: formData.name,
      type: formData.type,
      calories: parseInt(formData.calories) || 0,
      protein: parseInt(formData.protein) || 0,
      carbs: parseInt(formData.carbs) || 0,
      fat: parseInt(formData.fat) || 0,
      time: formData.time,
      portion: formData.portion
    }
    setMeals([...meals, newMeal])
    setFormData({ name: "", type: "Breakfast", calories: "", protein: "", carbs: "", fat: "", time: "", portion: "" })
    setShowForm(false)
  }

  const deleteMeal = (id: number) => {
    setMeals(meals.filter(m => m.id !== id))
  }

  const quickAddFood = (food: typeof recentFoods[0]) => {
    setFormData({
      name: food.name,
      type: "Snack",
      calories: food.calories.toString(),
      protein: food.protein.toString(),
      carbs: food.carbs.toString(),
      fat: food.fat.toString(),
      time: new Date().toTimeString().slice(0, 5),
      portion: "1 serving"
    })
    setShowForm(true)
  }

  const filteredFoods = recentFoods.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const totalCalories = meals.reduce((sum, m) => sum + m.calories, 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Food Log</h1>
          <p className="text-muted-foreground mt-1">Track your meals and nutrition</p>
        </div>
        <Button 
          onClick={() => setShowForm(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Log Meal
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Add Meal Form */}
          {showForm && (
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-card-foreground">Log New Meal</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-foreground">Food Name</Label>
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="e.g., Grilled Chicken"
                        required
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Meal Type</Label>
                      <select
                        value={formData.type}
                        onChange={(e) => setFormData({...formData, type: e.target.value})}
                        className="w-full h-10 px-3 rounded-md bg-input border border-border text-foreground"
                      >
                        {mealTypes.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label className="text-foreground">Calories</Label>
                      <Input
                        type="number"
                        value={formData.calories}
                        onChange={(e) => setFormData({...formData, calories: e.target.value})}
                        placeholder="kcal"
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Protein (g)</Label>
                      <Input
                        type="number"
                        value={formData.protein}
                        onChange={(e) => setFormData({...formData, protein: e.target.value})}
                        placeholder="g"
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Carbs (g)</Label>
                      <Input
                        type="number"
                        value={formData.carbs}
                        onChange={(e) => setFormData({...formData, carbs: e.target.value})}
                        placeholder="g"
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Fat (g)</Label>
                      <Input
                        type="number"
                        value={formData.fat}
                        onChange={(e) => setFormData({...formData, fat: e.target.value})}
                        placeholder="g"
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-foreground">Time</Label>
                      <Input
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({...formData, time: e.target.value})}
                        className="bg-input border-border text-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Portion Size</Label>
                      <Input
                        value={formData.portion}
                        onChange={(e) => setFormData({...formData, portion: e.target.value})}
                        placeholder="e.g., 1 cup, 200g"
                        className="bg-input border-border text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Save Meal
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="border-border text-foreground">
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {/* Meals by Type */}
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="bg-accent/50">
              <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">All</TabsTrigger>
              {mealTypes.map(type => (
                <TabsTrigger key={type} value={type.toLowerCase()} className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  {type}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="all" className="mt-4">
              <MealsList meals={meals} onDelete={deleteMeal} />
            </TabsContent>
            {mealTypes.map(type => (
              <TabsContent key={type} value={type.toLowerCase()} className="mt-4">
                <MealsList meals={meals.filter(m => m.type === type)} onDelete={deleteMeal} />
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Today's Summary */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">Today&apos;s Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-4">
                <p className="text-4xl font-bold text-primary">{totalCalories}</p>
                <p className="text-sm text-muted-foreground">calories consumed</p>
              </div>
              <div className="h-2 bg-accent rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary rounded-full transition-all"
                  style={{ width: `${Math.min((totalCalories / 2000) * 100, 100)}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground text-center mt-2">
                {2000 - totalCalories > 0 ? `${2000 - totalCalories} kcal remaining` : 'Goal reached!'}
              </p>
            </CardContent>
          </Card>

          {/* Quick Add */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">Quick Add</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search foods..."
                  className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {filteredFoods.map((food, index) => (
                  <button
                    key={index}
                    onClick={() => quickAddFood(food)}
                    className="w-full flex items-center justify-between p-3 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors text-left"
                  >
                    <div>
                      <p className="text-sm font-medium text-card-foreground">{food.name}</p>
                      <p className="text-xs text-muted-foreground">{food.calories} kcal</p>
                    </div>
                    <Plus className="w-4 h-4 text-primary" />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function MealsList({ meals, onDelete }: { meals: Meal[], onDelete: (id: number) => void }) {
  if (meals.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No meals logged yet</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {meals.map((meal) => (
        <Card key={meal.id} className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-lg">
                  {meal.type === "Breakfast" ? "🍳" : meal.type === "Lunch" ? "🥗" : meal.type === "Dinner" ? "🍽️" : "🍎"}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-card-foreground truncate">{meal.name}</p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>{meal.type}</span>
                  <span>•</span>
                  <Clock className="w-3 h-3" />
                  <span>{meal.time}</span>
                  <span>•</span>
                  <span>{meal.portion}</span>
                </div>
              </div>
              <div className="text-right hidden sm:block">
                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <p className="font-semibold text-card-foreground">{meal.calories}</p>
                    <p className="text-xs text-muted-foreground">kcal</p>
                  </div>
                  <div>
                    <p className="font-semibold text-card-foreground">{meal.protein}g</p>
                    <p className="text-xs text-muted-foreground">protein</p>
                  </div>
                  <div>
                    <p className="font-semibold text-card-foreground">{meal.carbs}g</p>
                    <p className="text-xs text-muted-foreground">carbs</p>
                  </div>
                  <div>
                    <p className="font-semibold text-card-foreground">{meal.fat}g</p>
                    <p className="text-xs text-muted-foreground">fat</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Edit2 className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => onDelete(meal.id)}
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
