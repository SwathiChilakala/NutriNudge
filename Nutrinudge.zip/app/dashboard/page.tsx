"use client"

import { useEffect, useState } from "react"
import { CaloriesChart } from "@/components/dashboard/calories-chart"
import { DailyProgress } from "@/components/dashboard/daily-progress"
import { MealHistory } from "@/components/dashboard/meal-history"
import { HydrationWidget } from "@/components/dashboard/hydration-widget"
import { DisciplineScore } from "@/components/dashboard/discipline-score"
import { AINudge } from "@/components/dashboard/ai-nudge"
import { WeeklyAnalytics } from "@/components/dashboard/weekly-analytics"
import { QuickActions } from "@/components/dashboard/quick-actions"

export default function DashboardPage() {
  const [userName, setUserName] = useState("")

  useEffect(() => {
    const userData = localStorage.getItem("nutrinudge_user")
    if (userData) {
      const user = JSON.parse(userData)
      setUserName(user.name || "User")
    }
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Welcome back, {userName || "User"}!</h1>
        <p className="text-muted-foreground mt-1">Here&apos;s your health overview for today</p>
      </div>
      
      <QuickActions />
      
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <DailyProgress />
          <CaloriesChart />
          <MealHistory />
        </div>
        
        <div className="space-y-6">
          <DisciplineScore />
          <HydrationWidget />
          <AINudge />
        </div>
      </div>
      
      <WeeklyAnalytics />
    </div>
  )
}
