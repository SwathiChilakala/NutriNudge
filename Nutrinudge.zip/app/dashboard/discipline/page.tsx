"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, TrendingUp, TrendingDown, Check, X, AlertCircle, Clock, Utensils, Droplets, Apple } from "lucide-react"
import {
  RadialBarChart,
  RadialBar,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts"

const scoreFactors = [
  { 
    name: "Meal Consistency", 
    score: 85, 
    description: "You've been eating at regular times",
    icon: Clock,
    color: "text-chart-1",
    bgColor: "bg-chart-1/10"
  },
  { 
    name: "Hydration", 
    score: 70, 
    description: "Drinking enough water most days",
    icon: Droplets,
    color: "text-chart-3",
    bgColor: "bg-chart-3/10"
  },
  { 
    name: "Healthy Choices", 
    score: 90, 
    description: "Excellent food selections this week",
    icon: Apple,
    color: "text-primary",
    bgColor: "bg-primary/10"
  },
  { 
    name: "Meal Logging", 
    score: 75, 
    description: "Logging meals consistently",
    icon: Utensils,
    color: "text-chart-4",
    bgColor: "bg-chart-4/10"
  },
]

const weeklyTrend = [
  { day: "Mon", score: 78 },
  { day: "Tue", score: 82 },
  { day: "Wed", score: 75 },
  { day: "Thu", score: 85 },
  { day: "Fri", score: 80 },
  { day: "Sat", score: 72 },
  { day: "Sun", score: 82 },
]

const habits = [
  { habit: "Ate breakfast", completed: true },
  { habit: "Drank 8 glasses of water", completed: false },
  { habit: "No late-night snacking", completed: true },
  { habit: "Ate 5 servings of vegetables", completed: true },
  { habit: "Limited processed food", completed: true },
  { habit: "No sugary drinks", completed: false },
]

const insights = [
  {
    type: "positive",
    title: "Great meal timing!",
    description: "You've eaten breakfast for 6 days straight. Keep it up!"
  },
  {
    type: "warning",
    title: "Hydration needs attention",
    description: "You missed your water goal 3 times this week. Try setting reminders."
  },
  {
    type: "positive",
    title: "Healthy choices improving",
    description: "Your junk food consumption is down 40% from last month."
  },
]

export default function DisciplinePage() {
  const overallScore = Math.round(scoreFactors.reduce((acc, f) => acc + f.score, 0) / scoreFactors.length)
  const scoreChange = 5

  const radialData = [
    { name: "Score", value: overallScore, fill: "oklch(0.55 0.15 145)" }
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Discipline Score</h1>
        <p className="text-muted-foreground mt-1">Track your overall health discipline and build better habits</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Score */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-8">
                {/* Score Ring */}
                <div className="relative w-48 h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart
                      cx="50%"
                      cy="50%"
                      innerRadius="70%"
                      outerRadius="90%"
                      barSize={12}
                      data={radialData}
                      startAngle={90}
                      endAngle={-270}
                    >
                      <RadialBar
                        background={{ fill: "oklch(0.88 0.05 145)" }}
                        dataKey="value"
                        cornerRadius={10}
                      />
                    </RadialBarChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Activity className="w-6 h-6 text-primary mb-1" />
                    <span className="text-4xl font-bold text-foreground">{overallScore}</span>
                    <span className="text-sm text-muted-foreground">out of 100</span>
                  </div>
                </div>

                {/* Score Details */}
                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-foreground mb-1">Your Discipline Score</h3>
                    <div className="flex items-center gap-2">
                      {scoreChange >= 0 ? (
                        <div className="flex items-center gap-1 text-primary">
                          <TrendingUp className="w-4 h-4" />
                          <span className="font-medium">+{scoreChange}%</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-destructive">
                          <TrendingDown className="w-4 h-4" />
                          <span className="font-medium">{scoreChange}%</span>
                        </div>
                      )}
                      <span className="text-sm text-muted-foreground">from last week</span>
                    </div>
                  </div>

                  <p className="text-muted-foreground">
                    {overallScore >= 80 
                      ? "Excellent work! You're maintaining great eating discipline."
                      : overallScore >= 60
                      ? "Good progress! Focus on your weakest areas to improve."
                      : "There's room for improvement. Start with small, consistent changes."
                    }
                  </p>

                  <div className="flex gap-2">
                    <div className="px-3 py-1.5 rounded-full bg-primary/10 text-sm text-primary font-medium">
                      Level: {overallScore >= 80 ? "Expert" : overallScore >= 60 ? "Intermediate" : "Beginner"}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Score Breakdown */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 gap-4">
                {scoreFactors.map((factor) => (
                  <div key={factor.name} className="p-4 rounded-xl bg-accent/30">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`w-10 h-10 rounded-lg ${factor.bgColor} flex items-center justify-center`}>
                        <factor.icon className={`w-5 h-5 ${factor.color}`} />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{factor.name}</p>
                        <p className="text-xs text-muted-foreground">{factor.description}</p>
                      </div>
                      <span className="text-lg font-bold text-foreground">{factor.score}%</span>
                    </div>
                    <div className="h-2 bg-accent rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all"
                        style={{ width: `${factor.score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Weekly Trend */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-card-foreground">Weekly Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={weeklyTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.04 145)" />
                    <XAxis
                      dataKey="day"
                      tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                      axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                      tickLine={false}
                    />
                    <YAxis
                      domain={[0, 100]}
                      tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                      axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(0.99 0.01 145)",
                        border: "1px solid oklch(0.88 0.04 145)",
                        borderRadius: "12px",
                        color: "oklch(0.2 0.04 145)",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="score"
                      stroke="oklch(0.55 0.15 145)"
                      strokeWidth={3}
                      dot={{ fill: "oklch(0.55 0.15 145)", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Today's Habits */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">Today&apos;s Habits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {habits.map((item, index) => (
                  <div key={index} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/30">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${item.completed ? 'bg-primary' : 'bg-accent'}`}>
                      {item.completed ? (
                        <Check className="w-4 h-4 text-primary-foreground" />
                      ) : (
                        <X className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                    <span className={`text-sm ${item.completed ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {item.habit}
                    </span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-4 text-center">
                {habits.filter(h => h.completed).length}/{habits.length} habits completed today
              </p>
            </CardContent>
          </Card>

          {/* AI Insights */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold text-card-foreground">AI Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {insights.map((insight, index) => (
                <div 
                  key={index} 
                  className={`p-3 rounded-lg border ${
                    insight.type === 'positive' 
                      ? 'bg-primary/5 border-primary/20' 
                      : 'bg-chart-4/5 border-chart-4/20'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <AlertCircle className={`w-4 h-4 mt-0.5 ${insight.type === 'positive' ? 'text-primary' : 'text-chart-4'}`} />
                    <div>
                      <p className="text-sm font-medium text-foreground">{insight.title}</p>
                      <p className="text-xs text-muted-foreground mt-1">{insight.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
