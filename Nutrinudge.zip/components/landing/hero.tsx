import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, Apple, Droplets, Trophy } from "lucide-react"

export function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30">
              <Sparkles className="w-4 h-4 text-secondary" />
              <span className="text-sm font-medium text-foreground">AI-Powered Health Companion</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Smart AI for{" "}
              <span className="text-primary">Conscious Eating</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Transform your relationship with food. Track meals, analyze patterns, 
              and receive personalized nudges to build lasting healthy habits.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/signup">
                <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/80 px-8 h-14 text-lg font-semibold shadow-lg shadow-primary/30 transition-all duration-200 hover:shadow-primary/40 hover:scale-[1.02]">
                  Start Your Journey
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="#how-it-works">
                <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/80 h-14 text-lg px-8 font-semibold shadow-lg shadow-secondary/30 transition-all duration-200 hover:shadow-secondary/40 hover:scale-[1.02]">
                  Learn More
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center gap-8 pt-4 flex-wrap">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                  <Apple className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">50K+</p>
                  <p className="text-xs text-muted-foreground">Meals Tracked</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-secondary/20 border border-secondary/30 flex items-center justify-center">
                  <Droplets className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">10K+</p>
                  <p className="text-xs text-muted-foreground">Active Users</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">95%</p>
                  <p className="text-xs text-muted-foreground">Success Rate</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative lg:h-[600px] hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 rounded-3xl" />
            <div className="absolute top-8 right-8 left-8 bottom-8 bg-card rounded-2xl shadow-2xl border border-primary/20 overflow-hidden">
              <div className="p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Today&apos;s Progress</p>
                    <p className="text-2xl font-bold text-foreground">1,450 kcal</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-xl font-bold text-primary">72%</span>
                  </div>
                </div>
                
                <div className="h-4 bg-accent rounded-full overflow-hidden">
                  <div className="h-full w-[72%] bg-primary rounded-full" />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-accent/50 rounded-xl p-4 text-center">
                    <p className="text-xs text-muted-foreground">Protein</p>
                    <p className="text-lg font-semibold text-foreground">65g</p>
                  </div>
                  <div className="bg-accent/50 rounded-xl p-4 text-center">
                    <p className="text-xs text-muted-foreground">Carbs</p>
                    <p className="text-lg font-semibold text-foreground">180g</p>
                  </div>
                  <div className="bg-accent/50 rounded-xl p-4 text-center">
                    <p className="text-xs text-muted-foreground">Fats</p>
                    <p className="text-lg font-semibold text-foreground">45g</p>
                  </div>
                </div>
                
                <div className="bg-primary/5 rounded-xl p-4 border border-primary/20">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-foreground">AI Nudge</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Great job on your protein intake! Consider adding more fiber to reach your daily goal.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <p className="text-sm font-medium text-foreground">Recent Meals</p>
                  <div className="flex items-center gap-3 p-3 bg-accent/30 rounded-xl">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-lg">🥗</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">Greek Salad</p>
                      <p className="text-xs text-muted-foreground">Lunch - 320 kcal</p>
                    </div>
                    <span className="text-xs text-primary font-medium">+5 pts</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-accent/30 rounded-xl">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-lg">🍳</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">Scrambled Eggs</p>
                      <p className="text-xs text-muted-foreground">Breakfast - 280 kcal</p>
                    </div>
                    <span className="text-xs text-primary font-medium">+3 pts</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
