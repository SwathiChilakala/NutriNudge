import { Camera, Brain, Droplets, Target, Trophy, BarChart3 } from "lucide-react"

const features = [
  {
    icon: Camera,
    title: "AI Food Recognition",
    description: "Snap a photo of your meal and let our AI instantly identify foods and calculate nutritional values.",
    color: "primary"
  },
  {
    icon: Brain,
    title: "Smart Nudges",
    description: "Receive personalized recommendations and motivational messages based on your eating patterns.",
    color: "secondary"
  },
  {
    icon: Droplets,
    title: "Hydration Tracking",
    description: "Monitor your daily water intake with smart reminders to stay properly hydrated throughout the day.",
    color: "primary"
  },
  {
    icon: Target,
    title: "Pattern Analysis",
    description: "Identify late-night eating, skipped meals, and junk food habits with detailed behavior insights.",
    color: "secondary"
  },
  {
    icon: Trophy,
    title: "Gamification",
    description: "Earn badges, maintain streaks, and unlock achievements as you build healthier eating habits.",
    color: "primary"
  },
  {
    icon: BarChart3,
    title: "Discipline Score",
    description: "Track your overall health discipline with a comprehensive score based on your daily choices.",
    color: "secondary"
  }
]

export function Features() {
  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-card">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Everything You Need for <span className="text-primary">Mindful Eating</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive tools powered by AI to help you understand, track, and improve your eating habits.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const isPrimary = feature.color === "primary"
            return (
              <div 
                key={index}
                className={`group p-6 bg-background rounded-2xl border transition-all duration-300 ${isPrimary ? 'border-primary/30 hover:border-primary/60 hover:shadow-xl hover:shadow-primary/10' : 'border-secondary/30 hover:border-secondary/60 hover:shadow-xl hover:shadow-secondary/10'}`}
              >
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-5 transition-colors ${isPrimary ? 'bg-primary/20 group-hover:bg-primary/30' : 'bg-secondary/20 group-hover:bg-secondary/30'}`}>
                  <feature.icon className={`w-7 h-7 ${isPrimary ? 'text-primary' : 'text-secondary'}`} />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
