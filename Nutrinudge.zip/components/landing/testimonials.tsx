import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Fitness Enthusiast",
    content: "NutriNudge completely transformed how I think about food. The AI nudges feel like having a personal nutritionist in my pocket!",
    rating: 5,
    avatar: "SC"
  },
  {
    name: "Michael Roberts",
    role: "Busy Professional",
    content: "I love how easy it is to log meals with photos. The pattern analysis helped me realize I was skipping breakfast way too often.",
    rating: 5,
    avatar: "MR"
  },
  {
    name: "Emily Davis",
    role: "Health Coach",
    content: "As a health coach, I recommend NutriNudge to all my clients. The gamification keeps them engaged and motivated!",
    rating: 5,
    avatar: "ED"
  }
]

export function Testimonials() {
  return (
    <section id="testimonials" className="py-20 px-4 sm:px-6 lg:px-8 bg-card">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Loved by <span className="text-primary">Thousands</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See what our community has to say about their NutriNudge experience.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="p-6 bg-card rounded-2xl border border-border hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300"
            >
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
                ))}
              </div>
              <p className="text-foreground mb-6 leading-relaxed">&quot;{testimonial.content}&quot;</p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-semibold text-primary">{testimonial.avatar}</span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
