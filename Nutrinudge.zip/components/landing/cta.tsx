import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Leaf } from "lucide-react"

export function CTA() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/30 mb-8 shadow-lg shadow-primary/20">
          <Leaf className="w-10 h-10 text-primary" />
        </div>
        
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6 text-balance">
          Ready to Transform Your Eating Habits?
        </h2>
        
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Join thousands of users who have already discovered the power of mindful eating with NutriNudge.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/signup">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/80 px-8 h-14 text-lg font-semibold shadow-lg shadow-primary/30 transition-all duration-200 hover:scale-[1.02]">
              Start Free Trial
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Link href="/login">
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/80 h-14 text-lg px-8 font-semibold shadow-lg shadow-secondary/30 transition-all duration-200 hover:scale-[1.02]">
              Sign In
            </Button>
          </Link>
        </div>
        
        <p className="text-sm text-muted-foreground mt-6">
          No credit card required. Free 14-day trial.
        </p>
      </div>
    </section>
  )
}
