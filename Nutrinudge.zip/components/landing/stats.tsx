const stats = [
  { value: "50K+", label: "Meals Logged Daily" },
  { value: "10K+", label: "Active Users" },
  { value: "95%", label: "User Satisfaction" },
  { value: "4.9", label: "App Store Rating" }
]

export function Stats() {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-primary">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-4xl sm:text-5xl font-bold text-primary-foreground mb-2">{stat.value}</p>
              <p className="text-primary-foreground/80">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
