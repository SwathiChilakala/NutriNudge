import { UserPlus, Utensils, Sparkles, TrendingUp } from "lucide-react"

const steps = [
  {
    icon: UserPlus,
    step: "01",
    title: "Create Your Profile",
    description: "Set up your account with your health goals, dietary preferences, and daily targets.",
    color: "primary"
  },
  {
    icon: Utensils,
    step: "02",
    title: "Log Your Meals",
    description: "Track your food intake using text, photos, or voice. Our AI makes logging effortless.",
    color: "secondary"
  },
  {
    icon: Sparkles,
    step: "03",
    title: "Get AI Insights",
    description: "Receive personalized nudges, pattern analysis, and smart recommendations daily.",
    color: "primary"
  },
  {
    icon: TrendingUp,
    step: "04",
    title: "Build Better Habits",
    description: "Watch your discipline score grow as you develop lasting healthy eating habits.",
    color: "secondary"
  }
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            How <span className="text-primary">NutriNudge</span> Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Start your journey to mindful eating in four simple steps.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((item, index) => {
            const isPrimary = item.color === "primary"
            return (
              <div key={index} className="relative">
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-14 left-[60%] w-[80%] h-[2px] bg-border" />
                )}
                <div className="relative z-10 text-center">
                  <div className={`inline-flex items-center justify-center w-28 h-28 rounded-full mb-6 relative border-2 ${isPrimary ? 'bg-primary/20 border-primary/30' : 'bg-secondary/20 border-secondary/30'}`}>
                    <item.icon className={`w-12 h-12 ${isPrimary ? 'text-primary' : 'text-secondary'}`} />
                    <span className={`absolute -top-2 -right-2 w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${isPrimary ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                      {item.step}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
