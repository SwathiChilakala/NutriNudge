"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Droplets, Plus } from "lucide-react"

export function HydrationWidget() {
  const current = 5
  const target = 8
  const percentage = (current / target) * 100

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
          <Droplets className="w-5 h-5 text-chart-3" />
          Hydration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="relative w-24 h-24">
            <svg className="w-24 h-24 -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="oklch(0.88 0.05 145)"
                strokeWidth="12"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="oklch(0.65 0.12 160)"
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={`${percentage * 2.51} 251`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <Droplets className="w-6 h-6 text-chart-3" />
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-card-foreground">{current}/{target}</p>
            <p className="text-sm text-muted-foreground">glasses today</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          {[...Array(target)].map((_, i) => (
            <div
              key={i}
              className={`flex-1 h-2 rounded-full ${
                i < current ? "bg-chart-3" : "bg-accent"
              }`}
            />
          ))}
        </div>
        
        <Button className="w-full bg-chart-3 text-primary-foreground hover:bg-chart-3/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Glass
        </Button>
      </CardContent>
    </Card>
  )
}
