"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sparkles, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

const nudges = [
  "Great job on your protein intake today! Consider adding some leafy greens to boost your fiber.",
  "You&apos;ve been consistent with breakfast this week - that&apos;s helping stabilize your energy levels!",
  "Try drinking a glass of water before your next meal to help with portion control.",
  "Your evening eating patterns have improved. Keep avoiding late-night snacks!",
  "Consider swapping your afternoon snack for nuts - they&apos;re a great source of healthy fats.",
]

export function AINudge() {
  const [nudgeIndex, setNudgeIndex] = useState(0)

  const refreshNudge = () => {
    setNudgeIndex((prev) => (prev + 1) % nudges.length)
  }

  return (
    <Card className="bg-primary/5 border-primary/20">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold text-card-foreground flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Nudge
        </CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={refreshNudge}
          className="h-8 w-8 text-primary hover:bg-primary/10"
        >
          <RefreshCw className="w-4 h-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-card-foreground leading-relaxed">{nudges[nudgeIndex]}</p>
      </CardContent>
    </Card>
  )
}
