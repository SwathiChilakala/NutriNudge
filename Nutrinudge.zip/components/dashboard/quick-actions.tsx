"use client"

import Link from "next/link"
import { Plus, Camera, Droplets, Target } from "lucide-react"
import { Button } from "@/components/ui/button"

const actions = [
  { icon: Plus, label: "Log Meal", href: "/dashboard/food-log", color: "bg-primary" },
  { icon: Camera, label: "Scan Food", href: "/dashboard/ai-tracking", color: "bg-chart-2" },
  { icon: Droplets, label: "Log Water", href: "/dashboard/hydration", color: "bg-chart-3" },
  { icon: Target, label: "Set Goals", href: "/dashboard/settings", color: "bg-chart-4" },
]

export function QuickActions() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
      {actions.map((action) => (
        <Link key={action.label} href={action.href}>
          <Button
            variant="outline"
            className="w-full h-auto py-4 flex flex-col items-center gap-2 border-border hover:bg-accent hover:border-primary/50 transition-all"
          >
            <div className={`w-10 h-10 rounded-xl ${action.color} flex items-center justify-center`}>
              <action.icon className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-sm font-medium text-foreground">{action.label}</span>
          </Button>
        </Link>
      ))}
    </div>
  )
}
