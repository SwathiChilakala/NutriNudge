"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Check } from "lucide-react"

const factors = [
  { name: "Meal Consistency", score: 85 },
  { name: "Hydration", score: 70 },
  { name: "Healthy Choices", score: 90 },
]

export function DisciplineScore() {
  const overallScore = Math.round(factors.reduce((acc, f) => acc + f.score, 0) / factors.length)

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-card-foreground">Discipline Score</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-center">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="oklch(0.88 0.05 145)"
                strokeWidth="10"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="oklch(0.55 0.15 145)"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${overallScore * 2.83} 283`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-card-foreground">{overallScore}</span>
              <span className="text-xs text-muted-foreground">out of 100</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-center gap-2 text-sm">
          <TrendingUp className="w-4 h-4 text-primary" />
          <span className="text-primary font-medium">+5% from last week</span>
        </div>
        
        <div className="space-y-2 pt-2">
          {factors.map((factor) => (
            <div key={factor.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                <span className="text-sm text-card-foreground">{factor.name}</span>
              </div>
              <span className="text-sm font-medium text-card-foreground">{factor.score}%</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
