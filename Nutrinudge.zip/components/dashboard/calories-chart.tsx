"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

const data = [
  { day: "Mon", calories: 1850 },
  { day: "Tue", calories: 1720 },
  { day: "Wed", calories: 2100 },
  { day: "Thu", calories: 1950 },
  { day: "Fri", calories: 1680 },
  { day: "Sat", calories: 2250 },
  { day: "Sun", calories: 1450 },
]

export function CaloriesChart() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-card-foreground">
          Weekly Calorie Intake
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorCalories" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.55 0.15 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.55 0.15 145)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.04 145)" />
              <XAxis
                dataKey="day"
                tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.99 0.01 145)",
                  border: "1px solid oklch(0.88 0.04 145)",
                  borderRadius: "12px",
                  color: "oklch(0.2 0.04 145)",
                }}
                labelStyle={{ color: "oklch(0.2 0.04 145)" }}
              />
              <Area
                type="monotone"
                dataKey="calories"
                stroke="oklch(0.55 0.15 145)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorCalories)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
