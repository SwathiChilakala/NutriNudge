"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Flame, Beef, Wheat, Droplet } from "lucide-react"

const nutrients = [
  { name: "Calories", current: 1450, target: 2000, unit: "kcal", icon: Flame, color: "text-chart-1" },
  { name: "Protein", current: 65, target: 120, unit: "g", icon: Beef, color: "text-chart-2" },
  { name: "Carbs", current: 180, target: 250, unit: "g", icon: Wheat, color: "text-chart-3" },
  { name: "Fats", current: 45, target: 65, unit: "g", icon: Droplet, color: "text-chart-4" },
]

export function DailyProgress() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-card-foreground">Daily Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {nutrients.map((nutrient) => {
            const percentage = Math.min((nutrient.current / nutrient.target) * 100, 100)
            return (
              <div key={nutrient.name} className="space-y-3">
                <div className="flex items-center gap-2">
                  <nutrient.icon className={`w-5 h-5 ${nutrient.color}`} />
                  <span className="text-sm font-medium text-card-foreground">{nutrient.name}</span>
                </div>
                <div className="space-y-2">
                  <div className="h-2 bg-accent rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-card-foreground font-medium">
                      {nutrient.current}{nutrient.unit}
                    </span>
                    <span className="text-muted-foreground">
                      / {nutrient.target}{nutrient.unit}
                    </span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
