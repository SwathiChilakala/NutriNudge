"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, Plus } from "lucide-react"
import Link from "next/link"

const meals = [
  {
    id: 1,
    name: "Oatmeal with Berries",
    type: "Breakfast",
    calories: 320,
    time: "8:00 AM",
    emoji: "🥣"
  },
  {
    id: 2,
    name: "Grilled Chicken Salad",
    type: "Lunch",
    calories: 450,
    time: "12:30 PM",
    emoji: "🥗"
  },
  {
    id: 3,
    name: "Greek Yogurt",
    type: "Snack",
    calories: 150,
    time: "3:00 PM",
    emoji: "🍨"
  },
  {
    id: 4,
    name: "Salmon with Vegetables",
    type: "Dinner",
    calories: 530,
    time: "7:00 PM",
    emoji: "🍣"
  },
]

export function MealHistory() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold text-card-foreground">Today&apos;s Meals</CardTitle>
        <Link href="/dashboard/food-log">
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-1" />
            Add Meal
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {meals.map((meal) => (
            <div
              key={meal.id}
              className="flex items-center gap-4 p-3 rounded-xl bg-accent/30 hover:bg-accent/50 transition-colors"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="text-xl">{meal.emoji}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-card-foreground truncate">{meal.name}</p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>{meal.type}</span>
                  <span>•</span>
                  <Clock className="w-3 h-3" />
                  <span>{meal.time}</span>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-card-foreground">{meal.calories}</p>
                <p className="text-xs text-muted-foreground">kcal</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
