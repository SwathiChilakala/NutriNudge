"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

const data = [
  { day: "Mon", healthy: 4, junk: 1 },
  { day: "Tue", healthy: 5, junk: 0 },
  { day: "Wed", healthy: 3, junk: 2 },
  { day: "Thu", healthy: 4, junk: 1 },
  { day: "Fri", healthy: 3, junk: 2 },
  { day: "Sat", healthy: 2, junk: 3 },
  { day: "Sun", healthy: 4, junk: 0 },
]

const stats = [
  { label: "Meals Logged", value: "28" },
  { label: "Avg. Calories", value: "1,857" },
  { label: "Hydration Goal", value: "6/7 days" },
  { label: "Skipped Meals", value: "2" },
]

export function WeeklyAnalytics() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-card-foreground">Weekly Analytics</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="p-4 rounded-xl bg-accent/30 text-center">
              <p className="text-2xl font-bold text-card-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-card-foreground mb-4">Healthy vs Junk Food Choices</h4>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.88 0.04 145)" />
                <XAxis
                  dataKey="day"
                  tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                  axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "oklch(0.45 0.03 145)", fontSize: 12 }}
                  axisLine={{ stroke: "oklch(0.88 0.04 145)" }}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.99 0.01 145)",
                    border: "1px solid oklch(0.88 0.04 145)",
                    borderRadius: "12px",
                    color: "oklch(0.2 0.04 145)",
                  }}
                  labelStyle={{ color: "oklch(0.2 0.04 145)" }}
                />
                <Legend />
                <Bar dataKey="healthy" fill="oklch(0.55 0.15 145)" radius={[4, 4, 0, 0]} name="Healthy" />
                <Bar dataKey="junk" fill="oklch(0.577 0.245 27.325)" radius={[4, 4, 0, 0]} name="Junk" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
