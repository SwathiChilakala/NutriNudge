"use client"

import { useEffect, useState } from "react"
import { Menu, Bell, Search, User, Settings, LogOut, Droplets, Apple, Trophy, Sparkles, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const notifications = [
  {
    id: 1,
    title: "Time to hydrate!",
    message: "You haven't logged water in 2 hours",
    icon: Droplets,
    time: "5 min ago",
    color: "text-secondary"
  },
  {
    id: 2,
    title: "Meal reminder",
    message: "Don't forget to log your lunch",
    icon: Apple,
    time: "1 hour ago",
    color: "text-primary"
  },
  {
    id: 3,
    title: "Achievement unlocked!",
    message: "You've maintained a 7-day streak",
    icon: Trophy,
    time: "2 hours ago",
    color: "text-secondary"
  },
  {
    id: 4,
    title: "AI Insight",
    message: "Your protein intake has improved 15%",
    icon: Sparkles,
    time: "Yesterday",
    color: "text-primary"
  }
]

interface DashboardHeaderProps {
  onMenuClick: () => void
}

export function DashboardHeader({ onMenuClick }: DashboardHeaderProps) {
  const [userInitials, setUserInitials] = useState("")
  const [userName, setUserName] = useState("")
  const [userEmail, setUserEmail] = useState("")
  const [userNotifications, setUserNotifications] = useState(notifications)

  function clearNotification(id: number) {
    setUserNotifications(prev => prev.filter(n => n.id !== id))
  }

  function clearAllNotifications() {
    setUserNotifications([])
  }

  useEffect(() => {
    const userData = localStorage.getItem("nutrinudge_user")
    if (userData) {
      const user = JSON.parse(userData)
      const name = user.name || "User"
      const initials = name.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2)
      setUserInitials(initials || "U")
      setUserName(name)
      setUserEmail(user.email || "")
    }
  }, [])

  return (
    <header className="sticky top-0 z-30 h-16 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center justify-between h-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 text-foreground hover:bg-accent rounded-lg"
          >
            <Menu className="w-6 h-6" />
          </button>
          
          <div className="hidden sm:block relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search meals, nutrients..."
              className="w-64 pl-10 h-10 bg-input border-border text-foreground placeholder:text-muted-foreground"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative text-foreground hover:bg-accent">
                <Bell className="w-5 h-5" />
                {userNotifications.length > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 bg-card border-border">
              <DropdownMenuLabel className="text-foreground flex items-center justify-between">
                <span>Notifications</span>
                {userNotifications.length > 0 && (
                  <button 
                    onClick={clearAllNotifications}
                    className="text-xs text-muted-foreground hover:text-primary transition-colors"
                  >
                    Clear all
                  </button>
                )}
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-border" />
              {userNotifications.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No notifications</p>
                </div>
              ) : (
                <div className="max-h-80 overflow-y-auto">
                  {userNotifications.map((notification) => (
                    <div 
                      key={notification.id}
                      className="flex items-start gap-3 p-3 hover:bg-accent/50 transition-colors group"
                    >
                      <div className={`w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 ${notification.color}`}>
                        <notification.icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{notification.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{notification.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                      </div>
                      <button 
                        onClick={() => clearNotification(notification.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 hover:bg-background rounded transition-all"
                      >
                        <X className="w-3 h-3 text-muted-foreground" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center hover:bg-primary/30 transition-colors cursor-pointer">
                <span className="text-sm font-semibold text-primary">{userInitials || "U"}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-card border-border">
              <DropdownMenuLabel className="text-foreground">
                <div className="flex flex-col">
                  <span className="font-semibold">{userName}</span>
                  <span className="text-xs text-muted-foreground font-normal">{userEmail}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem 
                onSelect={() => { window.location.href = "/dashboard/profile" }}
                className="text-foreground hover:bg-accent cursor-pointer"
              >
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                onSelect={() => { window.location.href = "/dashboard/settings" }}
                className="text-foreground hover:bg-accent cursor-pointer"
              >
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem 
                onSelect={() => {
                  localStorage.removeItem("nutrinudge_user")
                  window.location.href = "/"
                }}
                className="text-destructive hover:bg-destructive/10 cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
