import Link from "next/link"
import { Leaf, Apple, Droplets, Activity } from "lucide-react"

interface AuthLayoutProps {
  children: React.ReactNode
  title: string
  subtitle: string
}

export function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 flex-col justify-between p-12">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
            <Leaf className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">NutriNudge</span>
        </Link>
        
        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Transform your relationship with food
            </h1>
            <p className="text-lg text-muted-foreground">
              Join thousands who are building healthier eating habits with AI-powered guidance.
            </p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-primary/30">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <Apple className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Smart Food Tracking</p>
                <p className="text-sm text-muted-foreground">AI-powered meal recognition</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-secondary/30">
              <div className="w-12 h-12 rounded-lg bg-secondary/20 flex items-center justify-center">
                <Droplets className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Hydration Monitoring</p>
                <p className="text-sm text-muted-foreground">Stay on top of your water intake</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-primary/30">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <Activity className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Discipline Score</p>
                <p className="text-sm text-muted-foreground">Track your health progress</p>
              </div>
            </div>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} NutriNudge. All rights reserved.
        </p>
      </div>
      
      {/* Right side - Form */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-12">
        <div className="lg:hidden mb-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Leaf className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">NutriNudge</span>
          </Link>
        </div>
        
        <div className="w-full max-w-md mx-auto">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-foreground">{title}</h2>
            <p className="mt-2 text-muted-foreground">{subtitle}</p>
          </div>
          
          {children}
        </div>
      </div>
    </div>
  )
}
